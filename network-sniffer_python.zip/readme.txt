This program shows you, which websites the people of your own network are visiting. Instead of the ip-address is the DNS showed. Your own computer is excluded. In the begin is only a empty screen, it takes a whil unitl the app shows you the first package. Although this here is with pygame UI, I let the print-command. So you can copy+paste it in your browser.

Music by Eric Matyas